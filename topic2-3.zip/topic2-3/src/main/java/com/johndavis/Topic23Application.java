package com.johndavis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Topic23Application {

	public static void main(String[] args) {
		SpringApplication.run(Topic23Application.class, args);
	}

}
