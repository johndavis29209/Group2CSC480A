package com.johndavis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Topic23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
